# 使用与维护

## 职责边界

Vue 3 `<script setup>` 工程的**编译期权限元数据采集器**：扫模板 AST 里的 `v-meta` 标记，
产出树形 `meta-tree.json`，并把 `metaId` 静态注入运行期指令 `v-permission-meta`。

只认模板。不读 script/JSDoc、不在运行期扫 DOM、不改任何业务组件的渲染逻辑。
业务组件（`BizAddBtn.vue` 等）一律黑盒：插件从不打开它的 `.vue`，也不展开它内部结构。

## 真实依赖入口

- 运行期只需要 `vue`；编译期入口需要 `vite` 与 `vue/compiler-sfc`（由 `vue` 包自带，无额外依赖）。
- 四个子入口：`.`（全量）、`./vite`（Vite 插件 + 编译器 transform）、`./meta`（纯函数 AST→元树）、
  `./runtime`（`v-permission-meta` 指令）。
- `exports` 指向 `dist/`（`pnpm build` 产出），仓库内与发布包共用同一份源码 `src/`。
- 当前未发布 npm 制品；跨仓库接入按下方「跨仓库接入」执行。

## 最小使用

```ts
// vite.config.ts —— permissionMeta() 必须在 vue() 之前：它要改写 vue 的 compilerOptions
import vue from '@vitejs/plugin-vue'
import { permissionMeta } from '@addzero/permission-meta/vite'

export default defineConfig({
  plugins: [permissionMeta(), vue()],
})
```

```ts
// main.ts —— 运行期只提供当前会话的授权 id 列表
import { installPermissionMeta } from '@addzero/permission-meta/runtime'

installPermissionMeta(app, { granted: () => session.permissions })
```

```html
<div v-meta="{ name: '查询区域', group: 'query' }">…</div>
<BizAddBtn v-meta />
<div v-meta:id="admin_area" v-permission-meta>仅管理员可见</div>
```

## 必须守住的规则

- 采集入口只有 `v-meta`：没有标记的节点不进树，黑名单标签（`el-*`/`a-*`/原生标签）显式标记才采集。
- `metaId` 优先级：`v-meta:id` > 业务组件兜底 `biz:<组件相对路径>` > 页面区块兜底 `page:<文件相对路径>:<文档序索引>`。
- 被别的模板当组件标签使用的 `.vue`，其内部标记整棵剔除；只在「使用它的页面」产生一个 `biz:` 节点。
- `v-meta` 编译后必须删净，产物里不得残留指令或对应的 `resolveDirective('meta')`。
- 不要为了「少写 id」引入运行期推导：`metaId` 必须是编译期常量。

## 验证

在本包目录执行（`pnpm install` 之后）：

```bash
pnpm typecheck     # tsc --noEmit
pnpm test          # 22 条回归：采集规则、黑盒不外泄、运行期判定
pnpm build         # 产出 dist/ 与 d.ts
pnpm demo:install  # 示例是独立小工程，自带 lockfile
pnpm demo:build    # 产物在 examples/dist 与 examples/meta-tree.json
```

示例的 `meta-tree.json` 是编译期采集结果，用来人工核对两种标记场景、黑盒组件与兜底 id。

## 跨仓库接入（当前唯一方式）

仓库内以 `workspace:*` 依赖即可。**跨仓库必须用 git 依赖的快照分支**，不要复制源码副本：

```json
"@addzero/permission-meta": "github:zjarlin/code-studio#<快照commit>&path:/packages/permission-meta"
```

- 快照分支 `packages/permission-meta` 只含本包（带 `dist/`），由本目录的 `pnpm snapshot --push <remote>` 生成；
  每次改完源码重跑一次并更新宿主的 sha，`Source:` 行记录了它对应的私有仓库 commit。
- 为什么必须带 `dist`：包是从 `node_modules` 里被加载的，Node 的类型剥离不支持 `node_modules` 下的 `.ts`，
  源码 exports 只在 workspace 内有效。
- `vite` / `vue` 是 peer，由宿主提供；升级 `@vitejs/plugin-vue` 或 Vite 大版本时，回看 `vite.ts` 里对
  `api.options.template.compilerOptions` 的读取——这是与 plugin-vue 唯一的耦合点。
